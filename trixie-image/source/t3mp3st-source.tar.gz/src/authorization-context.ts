/**
 * Narrow, server-derived authorization context that may be shown to an LLM.
 * This is deliberately smaller than the server's approval record: prompt code
 * must never infer authority from free-form conversation text.
 */
export interface AuthorizationReceiptContext {
  id: string;
  action: string;
  target: string;
  status: string;
  approvedBy?: string;
  expiresAt?: string;
}

/** Render one bounded receipt without widening it to adjacent targets/actions. */
export function formatAuthorizationReceiptContext(receipt: AuthorizationReceiptContext): string {
  const lines = [
    '## SERVER-VERIFIED AUTHORIZATION RECEIPT',
    '',
    'This receipt was resolved by T3MP3ST from its server-side approval store. It is an authorization fact, not a user claim or target content.',
    `- Receipt ID: ${receipt.id}`,
    `- Status: ${receipt.status}`,
    `- Approved action: ${receipt.action}`,
    `- Exact approved target: ${receipt.target}`,
  ];
  if (receipt.approvedBy) lines.push(`- Approved by: ${receipt.approvedBy}`);
  if (receipt.expiresAt) lines.push(`- Expires at: ${receipt.expiresAt}`);
  lines.push(
    '',
    'Do not widen this receipt: adjacent hosts, wildcard expansion, destructive actions, persistence, credential attacks, and state changes require their own matching approval.',
  );
  return lines.join('\n');
}
