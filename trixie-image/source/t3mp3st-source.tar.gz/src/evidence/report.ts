import { createHash } from 'crypto';
import { redactString } from '../redact.js';

export interface EvidenceReportEntry {
  id: string;
  findingId?: string;
  title?: string;
  type: string;
  content?: string;
  summary?: string;
  sha256?: string;
  path?: string;
  uri?: string;
  command?: string;
  source?: string;
  provenanceStrength?: string;
  timestamp?: number | string;
}

const SHA256_RE = /^[a-f0-9]{64}$/i;
const MAX_INLINE_CONTENT = 4000;

export function sha256EvidenceContent(content: string): string {
  return createHash('sha256').update(content).digest('hex');
}

function safeTimestamp(value: EvidenceReportEntry['timestamp']): string {
  if (value === undefined) return 'unknown';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? redactString(String(value)) : date.toISOString();
}

function tableCell(value: string | undefined): string {
  return redactString(value || '—').replace(/\|/g, '\\|').replace(/[\r\n]+/g, ' ');
}

function evidenceDigest(entry: EvidenceReportEntry): string {
  const supplied = entry.sha256?.trim().toLowerCase();
  if (supplied && SHA256_RE.test(supplied)) return supplied;
  return sha256EvidenceContent(entry.content || entry.summary || entry.command || entry.uri || entry.id);
}

/**
 * Render traceable, redacted evidence. Content is bounded in Markdown, while the
 * digest always covers the complete original value supplied to this function.
 */
export function renderEvidenceAppendix(
  entries: EvidenceReportEntry[],
  heading = 'Evidence Appendix',
): string {
  if (!entries.length) return '';

  const lines: string[] = [
    `## ${heading}`,
    '',
    'Evidence is linked by stable identifier and SHA-256. Sensitive values are redacted in this report.',
    '',
    '| ID | Finding | Type | Source | Captured | SHA-256 |',
    '|---|---|---|---|---|---|',
  ];

  for (const entry of entries) {
    lines.push(
      `| ${tableCell(entry.id)} | ${tableCell(entry.findingId)} | ${tableCell(entry.type)} | ${tableCell(entry.source)} | ${tableCell(safeTimestamp(entry.timestamp))} | \`${evidenceDigest(entry)}\` |`,
    );
  }
  lines.push('');

  entries.forEach((entry, index) => {
    const label = entry.title ? `${entry.id} — ${entry.title}` : entry.id || `EVIDENCE-${index + 1}`;
    lines.push(`### ${redactString(label)}`, '');
    lines.push(`- Type: ${redactString(entry.type || 'artifact')}`);
    lines.push(`- SHA-256: \`${evidenceDigest(entry)}\``);
    if (entry.findingId) lines.push(`- Finding: ${redactString(entry.findingId)}`);
    if (entry.source) lines.push(`- Source: ${redactString(entry.source)}`);
    if (entry.provenanceStrength) lines.push(`- Provenance: ${redactString(entry.provenanceStrength)}`);
    if (entry.timestamp !== undefined) lines.push(`- Captured: ${safeTimestamp(entry.timestamp)}`);
    if (entry.path) lines.push(`- Path: \`${redactString(entry.path)}\``);
    if (entry.uri) lines.push(`- URI: \`${redactString(entry.uri)}\``);
    if (entry.command) lines.push(`- Command: \`${redactString(entry.command)}\``);
    lines.push('');

    const raw = entry.content || entry.summary || '(reference only)';
    const redacted = redactString(raw);
    const bounded = redacted.length > MAX_INLINE_CONTENT
      ? `${redacted.slice(0, MAX_INLINE_CONTENT)}\n[truncated ${redacted.length - MAX_INLINE_CONTENT} characters; verify the complete artifact using the SHA-256 above]`
      : redacted;
    lines.push(...bounded.split(/\r?\n/).map(line => `    ${line}`), '');
  });

  return lines.join('\n').trimEnd();
}
