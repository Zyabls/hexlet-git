import { afterEach, describe, expect, it, vi } from 'vitest';
import { config } from '../config/index.js';
import { createOpenAIBackbone } from '../llm/index.js';

const previous = {
  key: process.env.OPENAI_API_KEY,
  base: process.env.OPENAI_BASE_URL,
  model: process.env.OPENAI_MODEL,
  timeout: process.env.TEMPEST_LLM_TIMEOUT_MS,
  maxOutput: process.env.TEMPEST_LLM_MAX_OUTPUT_TOKENS,
  temperature: process.env.TEMPEST_LLM_TEMPERATURE,
};

function restore(name: string, value: string | undefined): void {
  if (value === undefined) delete process.env[name];
  else process.env[name] = value;
}

afterEach(() => {
  vi.unstubAllGlobals();
  restore('OPENAI_API_KEY', previous.key);
  restore('OPENAI_BASE_URL', previous.base);
  restore('OPENAI_MODEL', previous.model);
  restore('TEMPEST_LLM_TIMEOUT_MS', previous.timeout);
  restore('TEMPEST_LLM_MAX_OUTPUT_TOKENS', previous.maxOutput);
  restore('TEMPEST_LLM_TEMPERATURE', previous.temperature);
});

describe('OpenAI-compatible reasoning responses', () => {
  it('preserves reasoning_content when an OpenAI-compatible gateway leaves content empty', async () => {
    process.env.OPENAI_API_KEY = 'test-only';
    process.env.OPENAI_BASE_URL = 'https://llm.corp.test/v1';
    process.env.OPENAI_MODEL = 'gpt-oss-120b';
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({
      choices: [{
        message: { content: '', reasoning_content: 'The usable model response' },
        finish_reason: 'length',
      }],
      model: 'gpt-oss-120b',
      usage: { prompt_tokens: 10, completion_tokens: 32, total_tokens: 42 },
    }), { status: 200, headers: { 'content-type': 'application/json' } })));

    const response = await createOpenAIBackbone().chat([{ role: 'user', content: 'test' }]);

    expect(response.content).toBe('The usable model response');
    expect(response.reasoningContent).toBe('The usable model response');
    expect(response.finishReason).toBe('length');
  });

  it('replays opaque reasoning state with the assistant tool call', async () => {
    process.env.OPENAI_API_KEY = 'test-only';
    process.env.OPENAI_BASE_URL = 'https://llm.corp.test/v1';
    process.env.OPENAI_MODEL = 'gpt-oss-120b';
    let body: any = {};
    vi.stubGlobal('fetch', vi.fn(async (_url, init) => {
      body = JSON.parse(String(init?.body || '{}'));
      return new Response(JSON.stringify({
        choices: [{ message: { content: 'done' }, finish_reason: 'stop' }],
        model: 'gpt-oss-120b',
      }), { status: 200, headers: { 'content-type': 'application/json' } });
    }));

    await createOpenAIBackbone().chat([
      { role: 'user', content: 'collect evidence' },
      {
        role: 'assistant',
        content: '',
        reasoningContent: 'opaque-provider-state',
        toolCalls: [{ id: 'call-1', name: 'evidence_hash', arguments: { value: 'abc' } }],
      },
      { role: 'tool', content: 'hash=123', toolCallId: 'call-1', name: 'evidence_hash' },
    ]);

    expect(body.messages[1].reasoning_content).toBe('opaque-provider-state');
    expect(body.messages[1].tool_calls[0].function.name).toBe('evidence_hash');
  });

  it('allows a longer provider HTTP timeout through TEMPEST_LLM_TIMEOUT_MS', () => {
    process.env.TEMPEST_LLM_TIMEOUT_MS = '300000';
    expect(config.getLLMConfig('openai').timeout).toBe(300000);
  });

  it('caps output reservation and sampling for a restrictive corporate gateway', async () => {
    process.env.OPENAI_API_KEY = 'test-only';
    process.env.OPENAI_BASE_URL = 'https://llm.corp.test/v1';
    process.env.OPENAI_MODEL = 'gpt-oss-120b';
    process.env.TEMPEST_LLM_MAX_OUTPUT_TOKENS = '512';
    process.env.TEMPEST_LLM_TEMPERATURE = '0';
    let body: Record<string, unknown> = {};
    vi.stubGlobal('fetch', vi.fn(async (_url, init) => {
      body = JSON.parse(String(init?.body || '{}'));
      return new Response(JSON.stringify({
        choices: [{ message: { content: 'ok' }, finish_reason: 'stop' }],
        model: 'gpt-oss-120b',
      }), { status: 200, headers: { 'content-type': 'application/json' } });
    }));

    await createOpenAIBackbone().chat([{ role: 'user', content: 'test' }], { maxTokens: 8192, temperature: 0.7 });

    expect(body.max_tokens).toBe(512);
    expect(body.temperature).toBe(0);
  });
});
