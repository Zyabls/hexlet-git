import { afterEach, describe, expect, it } from 'vitest';
import { config } from '../config/index.js';

const names = [
  'TEMPEST_ENFORCE_SERVER_LLM',
  'TEMPEST_DEFAULT_PROVIDER',
  'OPENAI_BASE_URL',
  'OPENAI_MODEL',
  'OPENAI_API_KEY',
] as const;
const previous = Object.fromEntries(names.map(name => [name, process.env[name]]));

afterEach(() => {
  for (const name of names) {
    const value = previous[name];
    if (value === undefined) delete process.env[name];
    else process.env[name] = value;
  }
});

describe('server-managed LLM lock', () => {
  it('ignores stale browser provider/model selections', () => {
    process.env.TEMPEST_ENFORCE_SERVER_LLM = '1';
    process.env.TEMPEST_DEFAULT_PROVIDER = 'openai';
    process.env.OPENAI_BASE_URL = 'http://127.0.0.1:18080/v1';
    process.env.OPENAI_MODEL = 'gpt-oss-120b';
    process.env.OPENAI_API_KEY = 'test-only';

    const resolved = config.getLLMConfig('openrouter', 'gpt-4-turbo-preview');

    expect(resolved.provider).toBe('openai');
    expect(resolved.model).toBe('gpt-oss-120b');
    expect(resolved.baseUrl).toBe('http://127.0.0.1:18080/v1');
    expect(resolved.apiKey).toBe('test-only');
  });
});
