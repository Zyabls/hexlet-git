import { describe, expect, it } from 'vitest';
import { AnalysisEngine } from '../analysis/index.js';
import { sha256EvidenceContent } from '../evidence/report.js';
import { KillChainPhase, type Report } from '../types/index.js';

describe('canonical evidence-backed report', () => {
  it('renders complete bounded evidence with stable ID, hash, metadata and redaction', () => {
    const secret = `sk-${'Z'.repeat(40)}`;
    const content = `HTTP/1.1 200 OK\nX-Canary: present\n${'proof-line\n'.repeat(40)}Authorization: Bearer ${secret}`;
    const report: Report = {
      id: 'report-evidence-1',
      missionId: 'mission-evidence-1',
      type: 'full_report',
      generatedAt: 1_700_000_000_000,
      summary: {
        overview: 'Synthetic evidence test.',
        riskRating: 'high',
        criticalFindings: 0,
        highFindings: 1,
        mediumFindings: 0,
        lowFindings: 0,
        infoFindings: 0,
        successfulExploits: 0,
        credentialsHarvested: 0,
        systemsCompromised: 0,
      },
      findings: [{
        id: 'finding-evidence-1',
        title: 'Synthetic canary finding',
        description: 'Local fixture only.',
        severity: 'high',
        targetId: 'local-fixture',
        operatorId: 'operator-1',
        phase: KillChainPhase.EXPLOIT,
        evidence: [{
          type: 'response',
          content,
          timestamp: 1_700_000_000_000,
          metadata: { id: 'EV-RESPONSE-1', path: '/evidence/response.txt', provenanceStrength: 'tool' },
        }],
        discoveredAt: 1_700_000_000_000,
      }],
      attackPaths: [],
      recommendations: [],
    };
    const engine = Object.create(AnalysisEngine.prototype) as AnalysisEngine;
    const markdown = engine.exportToMarkdown(report);

    expect(markdown).toContain('## Evidence Appendix');
    expect(markdown).toContain('EV-RESPONSE-1');
    expect(markdown).toContain(sha256EvidenceContent(content));
    expect(markdown).toContain('/evidence/response.txt');
    expect(markdown).toContain('    proof-line\n    proof-line\n    proof-line');
    expect(markdown).toContain('[redacted]');
    expect(markdown).not.toContain(secret);
  });
});
