import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const source = readFileSync(join(process.cwd(), 'src/llm/index.ts'), 'utf8');

describe('cloud LLM control-plane proxy isolation', () => {
  it('does not route hosted model requests through the attack-traffic dispatcher', () => {
    const hostedAdapters = source.slice(
      source.indexOf('class OpenRouterAdapter'),
      source.indexOf('class LocalAdapter'),
    );

    expect(hostedAdapters).toContain('fetchBypassingProxy(url');
    expect(hostedAdapters).not.toMatch(/await\s+fetch\s*\(url/);
  });
});
