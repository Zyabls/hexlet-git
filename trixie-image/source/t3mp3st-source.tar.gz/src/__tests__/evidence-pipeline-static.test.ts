import { readFileSync } from 'fs';
import { describe, expect, it } from 'vitest';

const server = readFileSync('src/server.ts', 'utf8');
const ui = readFileSync('docs/index.html', 'utf8');

describe('mission evidence pipeline wiring', () => {
  it('bridges embedded mission evidence into the persistent canonical ledger', () => {
    expect(server).toContain('mirrorMissionFindingEvidence(existing, finding.evidence)');
    expect(server).toContain('mirrorMissionFindingEvidence(record, finding.evidence)');
    expect(server).toContain("schedulePersist('mission.finding.mirrored')");
    expect(server).toContain('sha256EvidenceContent(content');
    expect(server).toContain('persistEvidenceArtifact(entry, content)');
  });

  it('captures executed tool output as evidence and can report it after restart', () => {
    expect(server).toContain("type: 'command'");
    expect(server).toContain("emitContractEvent('evidence.created'");
    expect(server).toContain('buildPersistedMissionReport(missionId)');
    expect(server).toContain("renderEvidenceAppendix(entries, 'Persistent Evidence Ledger')");
    expect(server).toContain("return process.env.T3MP3ST_STATE_DIR || 'memory'");
  });

  it('preserves structured evidence through SSE, hydration and report export', () => {
    expect(ui).toContain('function normalizeFindingEvidence(value)');
    expect(ui).toContain('evidence: normalizeFindingEvidence(finding.evidence)');
    expect(ui).toContain('evidence: normalizeFindingEvidence(f.evidence)');
    expect(ui).toContain("fetch(base + '/api/mission/report')");
    expect(ui).toContain('Canonical evidence-backed report exported');
    expect(ui).toContain('const evidenceText = findingEvidenceText(f)');
    expect(ui).not.toContain('escapeHtml(String(f.evidence))');
  });

  it('uses the persistent ledger when no mission is active', () => {
    expect(server).toContain('if (!cmd || !cmd.mission.getActiveMission())');
    expect(server).toContain('evidence: finding.evidenceIds');
  });
});
