import { describe, expect, it } from 'vitest';
import { findingToBountyFinding, getConnector } from '../integrations/bounty.js';

describe('bounty report evidence traceability', () => {
  it('carries structured evidence, hashes and vault references into Markdown', () => {
    const finding = findingToBountyFinding({
      id: 'finding-1',
      title: 'Synthetic report finding',
      severity_self: 'medium',
      summary: 'A deterministic local fixture finding.',
      root_cause: 'Synthetic test condition.',
      poc: '1. Open the local fixture.\n2. Observe the canary header.',
      impact: 'No production impact; acceptance fixture only.',
      remediation: 'Remove the synthetic canary.',
      evidence: [{
        id: 'EV-HTTP-1',
        type: 'http-response',
        content: 'HTTP/1.1 200 OK\nX-T3MP3ST-Canary: present',
        path: 'evidence/http-response.txt',
        sha256: 'a'.repeat(64),
      }],
      evidenceIds: ['EV-HTTP-1', 'EV-SCREENSHOT-2'],
    });

    const report = getConnector('hackerone').formatReport(finding, 'local-fixture');

    expect(report.body).toContain('## Evidence Appendix');
    expect(report.body).toContain('EV-HTTP-1');
    expect(report.body).toContain('EV-SCREENSHOT-2');
    expect(report.body).toContain('evidence/http-response.txt');
    expect(report.body).toContain('a'.repeat(64));
    expect(report.body).toContain('X-T3MP3ST-Canary: present');
  });

  it('resolves finding evidence IDs against the Evidence Vault ledger', () => {
    const ledger = new Map<string, unknown>([[
      'EV-LEDGER-7',
      {
        id: 'EV-LEDGER-7',
        type: 'response',
        title: 'Captured fixture response',
        summary: 'Synthetic response proved the bounded fixture condition.',
        command: 'curl http://127.0.0.1:8080/fixture',
        uri: 'evidence://EV-LEDGER-7',
      },
    ]]);
    const finding = findingToBountyFinding({
      title: 'Ledger-linked finding',
      severity: 'low',
      summary: 'Synthetic only.',
      evidenceIds: ['EV-LEDGER-7'],
    }, ledger);

    const report = getConnector('hackerone').formatReport(finding, 'local-fixture');
    expect(report.body).toContain('## Evidence Appendix');
    expect(report.body).toContain('EV-LEDGER-7');
    expect(report.body).toContain('Synthetic response proved');
    expect(report.body).toContain('curl http://127.0.0.1:8080/fixture');
    expect(report.body).toContain('evidence://EV-LEDGER-7');
  });

  it('redacts secrets before evidence reaches a platform draft', () => {
    const secret = `sk-${'A'.repeat(32)}`;
    const finding = findingToBountyFinding({
      title: 'Redaction fixture',
      severity_self: 'low',
      summary: 'Synthetic only.',
      evidence: [`Authorization: Bearer ${secret}`],
    });

    const report = getConnector('bugcrowd').formatReport(finding, 'local-fixture');

    expect(report.body).toContain('[redacted]');
    expect(report.body).not.toContain(secret);
  });

  it('maps persistent FindingRecord fields and evidence into every platform draft', () => {
    const ledger = new Map<string, unknown>([[
      'EV-PERSISTED-1',
      {
        id: 'EV-PERSISTED-1',
        type: 'command',
        content: 'HTTP/1.1 403 Forbidden changed to 200 after authorization check',
        summary: 'Reproducible local fixture output.',
        sha256: 'b'.repeat(64),
        path: '/var/lib/t3mp3st/evidence/fixture.txt',
      },
    ]]);
    const finding = findingToBountyFinding({
      id: 'finding-persisted-1',
      title: 'Persistent ledger finding',
      severity: 'critical',
      claim: 'Authorization is missing on the bounded fixture.',
      impact: 'A scoped test account can read another fixture record.',
      recommendedFix: 'Enforce object ownership before returning the record.',
      acceptanceCriteria: ['Cross-account request returns 403.'],
      evidenceIds: ['EV-PERSISTED-1'],
    }, ledger);

    expect(finding.severity).toBe('critical');
    expect(finding.summary).toContain('Authorization is missing');
    expect(finding.remediation).toContain('Enforce object ownership');
    for (const platform of ['hackerone', 'code4rena'] as const) {
      const report = getConnector(platform).formatReport(finding, 'local-fixture');
      expect(report.body).toContain('## Evidence Appendix');
      expect(report.body).toContain('EV-PERSISTED-1');
      expect(report.body).toContain('b'.repeat(64));
      expect(report.body).toContain('/var/lib/t3mp3st/evidence/fixture.txt');
    }
  });
});
