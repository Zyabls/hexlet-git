import { afterEach, describe, expect, it } from 'vitest';
import { config, AVAILABLE_MODELS } from '../config/index.js';
import { createLiteLLMBackbone } from '../llm/index.js';

const PREV_BASE = process.env.LITELLM_BASE_URL;
const PREV_KEY = process.env.LITELLM_API_KEY;
const PREV_MODEL = process.env.LITELLM_MODEL;
const PREV_FALLBACK_MODELS = process.env.LITELLM_FALLBACK_MODELS;
const PREV_FALLBACK_FLAG = process.env.TEMPEST_MODEL_FALLBACK;
const PREV_OPENROUTER_KEY = process.env.OPENROUTER_API_KEY;
const PREV_OPENROUTER_MODEL = process.env.OPENROUTER_MODEL;
const PREV_OPENAI_KEY = process.env.OPENAI_API_KEY;
const PREV_OPENAI_BASE = process.env.OPENAI_BASE_URL;
const PREV_OPENAI_MODEL = process.env.OPENAI_MODEL;

describe('LiteLLM provider wiring (#45)', () => {
  afterEach(() => {
    if (PREV_BASE === undefined) delete process.env.LITELLM_BASE_URL;
    else process.env.LITELLM_BASE_URL = PREV_BASE;
    if (PREV_KEY === undefined) delete process.env.LITELLM_API_KEY;
    else process.env.LITELLM_API_KEY = PREV_KEY;
    if (PREV_MODEL === undefined) delete process.env.LITELLM_MODEL;
    else process.env.LITELLM_MODEL = PREV_MODEL;
    if (PREV_FALLBACK_MODELS === undefined) delete process.env.LITELLM_FALLBACK_MODELS;
    else process.env.LITELLM_FALLBACK_MODELS = PREV_FALLBACK_MODELS;
    if (PREV_FALLBACK_FLAG === undefined) delete process.env.TEMPEST_MODEL_FALLBACK;
    else process.env.TEMPEST_MODEL_FALLBACK = PREV_FALLBACK_FLAG;
    if (PREV_OPENROUTER_KEY === undefined) delete process.env.OPENROUTER_API_KEY;
    else process.env.OPENROUTER_API_KEY = PREV_OPENROUTER_KEY;
    if (PREV_OPENROUTER_MODEL === undefined) delete process.env.OPENROUTER_MODEL;
    else process.env.OPENROUTER_MODEL = PREV_OPENROUTER_MODEL;
    if (PREV_OPENAI_KEY === undefined) delete process.env.OPENAI_API_KEY;
    else process.env.OPENAI_API_KEY = PREV_OPENAI_KEY;
    if (PREV_OPENAI_BASE === undefined) delete process.env.OPENAI_BASE_URL;
    else process.env.OPENAI_BASE_URL = PREV_OPENAI_BASE;
    if (PREV_OPENAI_MODEL === undefined) delete process.env.OPENAI_MODEL;
    else process.env.OPENAI_MODEL = PREV_OPENAI_MODEL;
  });

  it('resolves LiteLLM as an OpenAI-compatible proxy from env without requiring a key', () => {
    process.env.LITELLM_BASE_URL = 'http://localhost:4000/v1';
    delete process.env.LITELLM_API_KEY;
    process.env.LITELLM_MODEL = 'anthropic/claude-sonnet-4.5';

    const cfg = config.getLLMConfig('litellm');
    expect(cfg.provider).toBe('litellm');
    expect(cfg.baseUrl).toBe('http://localhost:4000/v1');
    expect(cfg.model).toBe('anthropic/claude-sonnet-4.5');
    expect(cfg.apiKey).toBeUndefined();
    expect(config.getConfiguredProviders()).toContain('litellm');
  });

  it('the LiteLLM backbone validates when only a proxy base URL is configured', () => {
    process.env.LITELLM_BASE_URL = 'http://localhost:4000/v1';
    const backbone = createLiteLLMBackbone();

    expect(backbone.getProvider()).toBe('litellm');
    expect(backbone.validateConfig().valid).toBe(true);
  });

  it('surfaces a static LiteLLM model catalog entry', () => {
    expect(AVAILABLE_MODELS.litellm?.length ?? 0).toBeGreaterThan(0);
    expect(AVAILABLE_MODELS.litellm[0].provider).toBe('LiteLLM');
  });

  it('uses env-configured endpoint and multiple models in the fallback ladder', () => {
    process.env.LITELLM_BASE_URL = 'https://api.groq.test/openai/v1';
    process.env.LITELLM_API_KEY = 'test-only';
    process.env.LITELLM_FALLBACK_MODELS = 'openai/gpt-oss-120b, qwen/qwen3.6-27b';
    process.env.OPENROUTER_API_KEY = 'test-openrouter';
    process.env.OPENROUTER_MODEL = 'openrouter/free';
    process.env.OPENAI_API_KEY = 'test-cloudflare';
    process.env.OPENAI_BASE_URL = 'https://api.cloudflare.test/client/v4/accounts/test/ai/v1';
    process.env.OPENAI_MODEL = '@cf/zai-org/glm-4.7-flash';
    process.env.TEMPEST_MODEL_FALLBACK = '1';

    const cfg = config.getLLMConfig('codex', 'codex-default');
    expect(cfg.fallbackChain).toEqual(expect.arrayContaining([
      expect.objectContaining({ provider: 'litellm', model: 'openai/gpt-oss-120b', baseUrl: 'https://api.groq.test/openai/v1' }),
      expect.objectContaining({ provider: 'litellm', model: 'qwen/qwen3.6-27b', baseUrl: 'https://api.groq.test/openai/v1' }),
      expect.objectContaining({ provider: 'openrouter', model: 'openrouter/free' }),
      expect.objectContaining({
        provider: 'openai',
        model: '@cf/zai-org/glm-4.7-flash',
        baseUrl: 'https://api.cloudflare.test/client/v4/accounts/test/ai/v1',
      }),
    ]));
    expect(cfg.fallbackChain?.findIndex((entry) => entry.model === 'qwen/qwen3.6-27b')).toBeLessThan(
      cfg.fallbackChain?.findIndex((entry) => entry.model === 'openrouter/free') ?? -1,
    );
    expect(cfg.fallbackChain?.findIndex((entry) => entry.model === 'openrouter/free')).toBeLessThan(
      cfg.fallbackChain?.findIndex((entry) => entry.model === '@cf/zai-org/glm-4.7-flash') ?? -1,
    );
  });

  it('uses the OpenAI-compatible endpoint and model overrides for Cloudflare', () => {
    process.env.OPENAI_API_KEY = 'test-cloudflare';
    process.env.OPENAI_BASE_URL = 'https://api.cloudflare.test/client/v4/accounts/test/ai/v1';
    process.env.OPENAI_MODEL = '@cf/zai-org/glm-4.7-flash';

    const cfg = config.getLLMConfig('openai');
    expect(cfg.apiKey).toBe('test-cloudflare');
    expect(cfg.baseUrl).toBe('https://api.cloudflare.test/client/v4/accounts/test/ai/v1');
    expect(cfg.model).toBe('@cf/zai-org/glm-4.7-flash');
  });
});
