import { describe, expect, it } from 'vitest';
import { AgentLoop } from '../agent/index.js';
import { Arsenal } from '../arsenal/index.js';
import { createMockBackbone } from '../llm/index.js';
import type { Target, Task } from '../types/index.js';

function task(): Task {
  return {
    id: 'task-1',
    name: 'Authorized reconnaissance',
    description: 'Perform bounded reconnaissance on the approved host.',
    phase: 'reconnaissance',
    priority: 5,
    operatorType: 'recon',
    status: 'pending',
    createdAt: Date.now(),
  } as Task;
}

function target(metadata?: Record<string, unknown>): Target {
  return {
    id: 'target-1',
    name: 'bounty.example',
    type: 'web_application',
    zone: 'external',
    status: 'discovered',
    address: 'bounty.example',
    protocol: 'https',
    metadata,
    discoveredAt: Date.now(),
  };
}

function render(targetValue: Target): string {
  const loop = new AgentLoop(createMockBackbone(), new Arsenal());
  return (loop as unknown as {
    buildTaskPrompt: (task: Task, target: Target, tools: unknown[]) => string;
  }).buildTaskPrompt(task(), targetValue, []);
}

describe('server-verified mission authorization in agent prompts', () => {
  it('renders the exact approved receipt and preserves narrow boundaries', () => {
    const prompt = render(target({
      authorizationReceipt: {
        id: 'approval-123',
        action: 'mission_execution',
        target: 'https://bounty.example/',
        status: 'approved',
        approvedBy: 'local-operator',
        expiresAt: '2026-08-06T10:00:00.000Z',
      },
    }));

    expect(prompt).toContain('Server-verified authorization receipt');
    expect(prompt).toContain('approval-123');
    expect(prompt).toContain('https://bounty.example/');
    expect(prompt).toContain('Adjacent hosts');
  });

  it('keeps an external target passive when no server receipt is attached', () => {
    const prompt = render(target());
    expect(prompt).toContain('No server-verified authorization receipt');
    expect(prompt).toContain('Do not perform active testing');
  });
});
