import { readFileSync } from 'fs';
import { describe, expect, it } from 'vitest';

const source = readFileSync(new URL('../server.ts', import.meta.url), 'utf8');
const commandFactory = source.slice(
  source.indexOf('function createTempestCommandInstance('),
  source.indexOf('// Wire all events to SSE broadcast'),
);

describe('TempestCommand server factory LLM configuration', () => {
  it('preserves timeout/fallback and honors output/sampling environment overrides', () => {
    expect(commandFactory).toContain('TEMPEST_LLM_MAX_OUTPUT_TOKENS');
    expect(commandFactory).toContain('TEMPEST_LLM_TEMPERATURE');
    expect(commandFactory).toContain('timeout: baseConfig.timeout');
    expect(commandFactory).toContain('fallbackChain: baseConfig.fallbackChain');
    expect(commandFactory).toContain(': baseConfig.maxTokens');
    expect(commandFactory).toContain(': baseConfig.temperature');
    expect(commandFactory).not.toContain('maxTokens: 4096');
    expect(commandFactory).not.toContain('temperature: 0.7');
  });
});
