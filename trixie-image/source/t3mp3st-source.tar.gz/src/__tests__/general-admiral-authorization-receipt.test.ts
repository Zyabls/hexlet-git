import { describe, expect, it, vi } from 'vitest';
import { Admiral } from '../admiral/index.js';
import { OpGeneral, type Directive } from '../general/index.js';
import type { AuthorizationReceiptContext } from '../authorization-context.js';

const receipt: AuthorizationReceiptContext = {
  id: 'approval-general-42',
  action: 'autonomous_execution',
  target: 'https://approved.example',
  status: 'approved',
  approvedBy: 'operator@example',
  expiresAt: '2026-08-12T10:00:00.000Z',
};

describe('authorization receipts in strategic prompts', () => {
  it('includes the exact server receipt in both General planning paths', () => {
    const general = new OpGeneral({} as any);
    const directive: Directive = {
      objective: 'Plan a bounded assessment.',
      scopeHints: 'approved.example only',
      authorizationReceipt: receipt,
    };
    const internal = general as any;

    for (const prompt of [
      internal.buildPlanningPrompt(directive),
      internal.buildCodexFastPlanningPrompt(directive),
    ]) {
      expect(prompt).toContain('SERVER-VERIFIED AUTHORIZATION RECEIPT');
      expect(prompt).toContain(receipt.id);
      expect(prompt).toContain(receipt.target);
      expect(prompt).toContain('Do not widen this receipt');
    }
  });

  it('includes only a server-supplied receipt in the Admiral system prompt', async () => {
    const chat = vi.fn().mockResolvedValue({
      content: JSON.stringify({
        reply: 'Brief ready.',
        brief: {
          objective: 'Assess the fixture',
          target: 'https://approved.example',
          family: 'pentest',
          scope: 'approved.example only',
          fidelity: 'dry_run',
        },
        missing: [],
        ready: true,
      }),
    });
    const admiral = new Admiral({ chat } as any);

    await admiral.converse([{ role: 'user', content: 'Prepare the authorized fixture assessment.' }], receipt);

    const messages = chat.mock.calls[0][0] as Array<{ role: string; content: string }>;
    expect(messages[0].role).toBe('system');
    expect(messages[0].content).toContain('SERVER-VERIFIED AUTHORIZATION RECEIPT');
    expect(messages[0].content).toContain(receipt.id);
    expect(messages[0].content).toContain(receipt.target);
  });
});
