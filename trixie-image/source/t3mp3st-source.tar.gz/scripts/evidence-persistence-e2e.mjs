#!/usr/bin/env node

import { createHash, randomUUID } from 'node:crypto';
import { mkdtemp, readdir, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawn } from 'node:child_process';

const projectRoot = resolve(import.meta.dirname, '..');
const tempRoot = await mkdtemp(join(tmpdir(), 't3mp3st-evidence-e2e-'));
const port = 33000 + Math.floor(Math.random() * 2000);
const baseUrl = `http://127.0.0.1:${port}`;
const missionId = `e2e-${randomUUID()}`;
const evidenceId = `EV-${randomUUID()}`;
const findingId = `FINDING-${randomUUID()}`;
const rawEvidence = [
  'HTTP/1.1 200 OK',
  'X-T3MP3ST-Evidence: persisted',
  'Authorization: Bearer sk-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA',
].join('\n');
const expectedSha = createHash('sha256').update(rawEvidence).digest('hex');
let server;

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

async function api(path, options = {}) {
  const response = await fetch(`${baseUrl}${path}`, options);
  const body = await response.text();
  if (!response.ok) throw new Error(`${path}: HTTP ${response.status}: ${body.slice(0, 500)}`);
  return JSON.parse(body);
}

async function waitForHealth() {
  for (let attempt = 0; attempt < 150; attempt += 1) {
    if (server?.exitCode !== null) {
      throw new Error(`server exited before health check: ${server?.stderrText || 'no stderr'}`);
    }
    try {
      await api('/api/health');
      return;
    } catch {
      await new Promise(resolvePromise => setTimeout(resolvePromise, 100));
    }
  }
  throw new Error(`server did not become healthy: ${server?.stderrText || 'no stderr'}`);
}

async function startServer(label) {
  const child = spawn(process.execPath, ['dist/server.js'], {
    cwd: projectRoot,
    env: {
      ...process.env,
      T3MP3ST_HOST: '127.0.0.1',
      T3MP3ST_PORT: String(port),
      T3MP3ST_MODE: 't3mp3st',
      T3MP3ST_STATE_DIR: join(tempRoot, 'state'),
      T3MP3ST_EVIDENCE_DIR: join(tempRoot, 'evidence'),
      T3MP3ST_REPORTS_DIR: join(tempRoot, 'reports'),
      OPENAI_API_KEY: 'relay-managed-local-only',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true,
  });
  child.stderrText = '';
  child.stderr.on('data', chunk => {
    child.stderrText = `${child.stderrText}${chunk}`.slice(-20000);
  });
  child.stdout.resume();
  child.once('error', error => {
    child.stderrText += `\n${label}: ${error.message}`;
  });
  server = child;
  await waitForHealth();
}

async function stopServer() {
  const child = server;
  server = undefined;
  if (!child || child.exitCode !== null) return;
  const exited = new Promise(resolvePromise => child.once('exit', resolvePromise));
  child.kill('SIGTERM');
  await Promise.race([exited, new Promise(resolvePromise => setTimeout(resolvePromise, 5000))]);
  if (child.exitCode === null) {
    child.kill('SIGKILL');
    await exited;
  }
}

try {
  await startServer('first start');
  const createdEvidence = await api('/api/evidence', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      id: evidenceId,
      missionId,
      type: 'log',
      title: 'Evidence persistence E2E fixture',
      summary: 'Local deterministic fixture.',
      content: rawEvidence,
      source: 'tool',
      provenanceStrength: 'tool',
    }),
  });
  assert(
    createdEvidence.sha256 === expectedSha,
    `evidence SHA-256 mismatch: expected ${expectedSha}, received ${createdEvidence.sha256}`,
  );
  assert(typeof createdEvidence.path === 'string', 'evidence artifact path is missing');
  assert(!JSON.stringify(createdEvidence).includes('sk-AAAAAAAA'), 'evidence response leaked the fixture secret');

  await api('/api/findings', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      id: findingId,
      missionId,
      family: 'web_api',
      title: 'Evidence persistence E2E finding',
      target: '127.0.0.1',
      claim: 'The canonical evidence is persisted.',
      impact: 'Local fixture only.',
      severity: 'high',
      confidence: 1,
      status: 'verified',
      evidenceIds: [evidenceId],
      resourceIds: [],
      recommendedFix: 'Remove the local fixture.',
      acceptanceCriteria: ['The fixture is absent.'],
    }),
  });

  await new Promise(resolvePromise => setTimeout(resolvePromise, 1500));
  const reportBefore = await api(`/api/mission/${missionId}/report`);
  assert(reportBefore.report.includes(evidenceId), 'pre-restart report lacks the Evidence ID');
  assert(reportBefore.report.includes(expectedSha), 'pre-restart report lacks the evidence SHA-256');
  assert(!reportBefore.report.includes('sk-AAAAAAAA'), 'pre-restart report leaked the fixture secret');
  assert(typeof reportBefore.reportPath === 'string', 'report artifact path is missing');
  await stat(reportBefore.reportPath);

  await stopServer();
  await startServer('second start');
  const restored = await api(`/api/evidence?missionId=${encodeURIComponent(missionId)}`);
  assert(
    restored.evidence.some(entry => entry.id === evidenceId && entry.sha256 === expectedSha),
    'Evidence ID/SHA-256 did not survive the server restart',
  );
  const reportAfter = await api(`/api/mission/${missionId}/report`);
  assert(reportAfter.report.includes(evidenceId), 'post-restart report lacks the Evidence ID');
  assert(reportAfter.report.includes(expectedSha), 'post-restart report lacks the evidence SHA-256');
  await stat(join(tempRoot, 'state', 'state.json'));
  const artifactCount = (await readdir(join(tempRoot, 'evidence'))).length;
  const reportCount = (await readdir(join(tempRoot, 'reports'))).length;
  assert(artifactCount >= 1, 'no evidence artifact was written');
  assert(reportCount >= 2, 'reports were not written before and after restart');

  console.log(JSON.stringify({
    status: 'pass', missionId, evidenceId, sha256: expectedSha, artifactCount, reportCount,
  }));
} finally {
  await stopServer();
  await rm(tempRoot, { recursive: true, force: true });
}
