#!/usr/bin/env bash
set -Eeuo pipefail

BOOTSTRAP=/root/t3mp3st-bootstrap
SOURCE_ARCHIVE="$BOOTSTRAP/t3mp3st-src-afc9dad1.tar.gz"
ADMIN_USER="${ADMIN_USER:-t3admin}"
NODE_VERSION="${NODE_VERSION:-24.16.0}"
NODE_LINUX_X64_SHA256="${NODE_LINUX_X64_SHA256:-d804845d34eddc21dc1092b519d643ef40b1f58ec5dec5c22b1f4bd8fabde6c9}"
CODEX_VERSION="${CODEX_VERSION:-0.146.0}"

[[ $EUID -eq 0 ]] || { echo "must run as root inside the container" >&2; exit 1; }
[[ -r "$SOURCE_ARCHIVE" ]] || { echo "source payload missing" >&2; exit 1; }
[[ "$ADMIN_USER" =~ ^[a-z_][a-z0-9_-]*$ ]] || { echo "invalid ADMIN_USER" >&2; exit 1; }

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends \
  ca-certificates curl xz-utils tar git openssh-server sudo build-essential \
  dnsutils whois nmap jq iproute2
apt-get clean
rm -rf /var/lib/apt/lists/*

NODE_TARBALL="node-v${NODE_VERSION}-linux-x64.tar.xz"
curl --fail --location --proto '=https' --tlsv1.2 \
  "https://nodejs.org/dist/v${NODE_VERSION}/${NODE_TARBALL}" \
  --output "/tmp/${NODE_TARBALL}"
printf '%s  %s\n' "$NODE_LINUX_X64_SHA256" "/tmp/${NODE_TARBALL}" | sha256sum --check --strict
rm -rf "/opt/node-v${NODE_VERSION}-linux-x64"
tar -xJf "/tmp/${NODE_TARBALL}" -C /opt
for bin in node npm npx corepack; do
  ln -sfn "/opt/node-v${NODE_VERSION}-linux-x64/bin/$bin" "/usr/local/bin/$bin"
done
rm -f "/tmp/${NODE_TARBALL}"

if ! id -u t3mp3st >/dev/null 2>&1; then
  useradd --system --create-home --home-dir /var/lib/t3mp3st/home --shell /bin/bash t3mp3st
fi
if ! id -u "$ADMIN_USER" >/dev/null 2>&1; then
  useradd --create-home --shell /bin/bash "$ADMIN_USER"
fi
usermod -aG sudo "$ADMIN_USER"
printf '%s ALL=(ALL:ALL) ALL\n' "$ADMIN_USER" > "/etc/sudoers.d/90-$ADMIN_USER"
chmod 0440 "/etc/sudoers.d/90-$ADMIN_USER"

if [[ -s /root/.ssh/authorized_keys ]]; then
  install -d -m 0700 -o "$ADMIN_USER" -g "$ADMIN_USER" "/home/$ADMIN_USER/.ssh"
  install -m 0600 -o "$ADMIN_USER" -g "$ADMIN_USER" \
    /root/.ssh/authorized_keys "/home/$ADMIN_USER/.ssh/authorized_keys"
fi

install -d -m 0750 -o t3mp3st -g t3mp3st \
  /var/lib/t3mp3st/home /var/lib/t3mp3st/state \
  /var/lib/t3mp3st/reports /var/lib/t3mp3st/evidence

RELEASE_DIR=/opt/t3mp3st-afc9dad1
STAGE_DIR=/opt/.t3mp3st-afc9dad1.new
rm -rf "$STAGE_DIR"
install -d -m 0755 -o t3mp3st -g t3mp3st "$STAGE_DIR"
tar -xzf "$SOURCE_ARCHIVE" -C "$STAGE_DIR" --strip-components=1
chown -R t3mp3st:t3mp3st "$STAGE_DIR"

runuser -u t3mp3st -- env HOME=/var/lib/t3mp3st/home \
  npm --prefix "$STAGE_DIR" ci --ignore-scripts --no-audit --no-fund
runuser -u t3mp3st -- env HOME=/var/lib/t3mp3st/home \
  npm --prefix "$STAGE_DIR" run build

rm -rf "$STAGE_DIR/reports" "$STAGE_DIR/evidence"
ln -s /var/lib/t3mp3st/reports "$STAGE_DIR/reports"
ln -s /var/lib/t3mp3st/evidence "$STAGE_DIR/evidence"

if [[ -e "$RELEASE_DIR" ]]; then
  mv "$RELEASE_DIR" "${RELEASE_DIR}.previous.$(date +%s)"
fi
mv "$STAGE_DIR" "$RELEASE_DIR"
ln -sfn "$RELEASE_DIR" /opt/t3mp3st

npm install --global --prefix /usr/local "@openai/codex@${CODEX_VERSION}" --no-audit --no-fund
codex --version

install -d -m 0755 /etc/t3mp3st
install -m 0640 -o root -g t3mp3st "$BOOTSTRAP/t3mp3st.env" /etc/t3mp3st/t3mp3st.env
install -m 0644 "$BOOTSTRAP/t3mp3st.service" /etc/systemd/system/t3mp3st.service

cat > /etc/ssh/sshd_config.d/99-t3mp3st-hardening.conf <<'EOF'
PasswordAuthentication no
KbdInteractiveAuthentication no
PermitRootLogin no
X11Forwarding no
AllowTcpForwarding yes
EOF
systemctl enable --now ssh

systemctl daemon-reload
systemctl enable --now t3mp3st

for _ in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:3333/health >/dev/null 2>&1; then exit 0; fi
  sleep 1
done
systemctl --no-pager --full status t3mp3st || true
journalctl -u t3mp3st --no-pager -n 80 || true
exit 1
