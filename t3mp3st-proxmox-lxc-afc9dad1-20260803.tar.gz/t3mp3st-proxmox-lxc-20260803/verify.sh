#!/usr/bin/env bash
set -Eeuo pipefail

CTID="${1:-}"
[[ $EUID -eq 0 ]] || { echo "run as root on the Proxmox VE host" >&2; exit 1; }
[[ "$CTID" =~ ^[0-9]+$ ]] || { echo "usage: $0 CTID" >&2; exit 2; }

pct status "$CTID"
pct exec "$CTID" -- systemctl is-active t3mp3st
pct exec "$CTID" -- systemctl --no-pager --full status t3mp3st | sed -n '1,18p'
pct exec "$CTID" -- curl -fsS http://127.0.0.1:3333/health
echo

LISTENERS="$(pct exec "$CTID" -- ss -lntp)"
printf '%s\n' "$LISTENERS" | grep -E '127\.0\.0\.1:3333|\[::1\]:3333' >/dev/null || {
  echo "T3MP3ST is not listening on loopback:3333" >&2; exit 1;
}
if printf '%s\n' "$LISTENERS" | grep -E '0\.0\.0\.0:3333|\[::\]:3333' >/dev/null; then
  echo "unsafe network bind detected on port 3333" >&2; exit 1
fi

pct exec "$CTID" -- node --version
pct exec "$CTID" -- codex --version
pct exec "$CTID" -- sshd -T | grep -E '^(passwordauthentication|permitrootlogin) '
echo "Verification passed: service healthy and UI is loopback-only."

