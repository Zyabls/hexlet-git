#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
CONFIG_FILE="${1:-$SCRIPT_DIR/config.env}"

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || die "required command not found: $1"; }

[[ $EUID -eq 0 ]] || die "run this script as root on a Proxmox VE host"
[[ -r "$CONFIG_FILE" ]] || die "configuration not found: $CONFIG_FILE (copy config.env.example first)"
# shellcheck disable=SC1090
source "$CONFIG_FILE"

for cmd in pct pveam pvesm awk grep sort tail sha256sum; do need "$cmd"; done

: "${CTID:?set CTID in config.env}"
: "${PVE_STORAGE:?set PVE_STORAGE in config.env}"
: "${TEMPLATE_STORAGE:?set TEMPLATE_STORAGE in config.env}"
: "${BRIDGE:?set BRIDGE in config.env}"
: "${IP_CONFIG:?set IP_CONFIG in config.env}"

[[ "$CTID" =~ ^[0-9]+$ ]] || die "CTID must be numeric"
(( CTID >= 100 )) || die "CTID must be at least 100"

CT_HOSTNAME="${CT_HOSTNAME:-t3mp3st}"
CORES="${CORES:-4}"
MEMORY_MB="${MEMORY_MB:-8192}"
SWAP_MB="${SWAP_MB:-2048}"
ROOTFS_GB="${ROOTFS_GB:-100}"
AUTOSTART="${AUTOSTART:-1}"
ADMIN_USER="${ADMIN_USER:-t3admin}"
NODE_VERSION="${NODE_VERSION:-24.16.0}"
NODE_LINUX_X64_SHA256="${NODE_LINUX_X64_SHA256:-d804845d34eddc21dc1092b519d643ef40b1f58ec5dec5c22b1f4bd8fabde6c9}"
CODEX_VERSION="${CODEX_VERSION:-0.146.0}"

[[ "$CT_HOSTNAME" =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]*$ ]] || die "invalid CT_HOSTNAME"
[[ "$ADMIN_USER" =~ ^[a-z_][a-z0-9_-]*$ ]] || die "invalid ADMIN_USER"
pvesm status --storage "$PVE_STORAGE" >/dev/null 2>&1 || die "PVE_STORAGE not found: $PVE_STORAGE"
pvesm status --storage "$TEMPLATE_STORAGE" >/dev/null 2>&1 || die "TEMPLATE_STORAGE not found: $TEMPLATE_STORAGE"

if pct status "$CTID" >/dev/null 2>&1; then
  die "CT $CTID already exists; choose a free CTID (nothing was changed)"
fi

PAYLOAD="$SCRIPT_DIR/payload"
for file in provision-inside-ct.sh t3mp3st.service t3mp3st.env t3mp3st-src-afc9dad1.tar.gz; do
  [[ -r "$PAYLOAD/$file" ]] || die "payload file missing: $PAYLOAD/$file"
done

if [[ -n "${PVE_TEMPLATE:-}" ]]; then
  TEMPLATE_REF="$PVE_TEMPLATE"
else
  TEMPLATE_NAME="$(pveam available --section system | awk '$2 ~ /^debian-13-standard_.*_amd64\.tar\.(zst|gz)$/ {print $2}' | sort -V | tail -n 1)"
  if [[ -z "$TEMPLATE_NAME" ]]; then
    TEMPLATE_NAME="$(pveam available --section system | awk '$2 ~ /^debian-12-standard_.*_amd64\.tar\.(zst|gz)$/ {print $2}' | sort -V | tail -n 1)"
  fi
  [[ -n "$TEMPLATE_NAME" ]] || die "no Debian 13/12 amd64 standard template is available"
  pveam download "$TEMPLATE_STORAGE" "$TEMPLATE_NAME"
  TEMPLATE_REF="$TEMPLATE_STORAGE:vztmpl/$TEMPLATE_NAME"
fi

NET0="name=eth0,bridge=$BRIDGE,firewall=1,$IP_CONFIG"
if [[ -n "${VLAN_TAG:-}" ]]; then
  [[ "$VLAN_TAG" =~ ^[0-9]+$ ]] || die "VLAN_TAG must be numeric"
  NET0+=",tag=$VLAN_TAG"
fi

CREATE_ARGS=(
  "$CTID" "$TEMPLATE_REF"
  --hostname "$CT_HOSTNAME"
  --ostype debian
  --unprivileged 1
  --cores "$CORES"
  --memory "$MEMORY_MB"
  --swap "$SWAP_MB"
  --rootfs "$PVE_STORAGE:$ROOTFS_GB"
  --net0 "$NET0"
  --onboot "$AUTOSTART"
  --start 0
)
if [[ -n "${DNS_SERVER:-}" ]]; then CREATE_ARGS+=(--nameserver "$DNS_SERVER"); fi
if [[ -n "${SSH_PUBLIC_KEY_FILE:-}" ]]; then
  [[ -r "$SSH_PUBLIC_KEY_FILE" ]] || die "SSH public key is not readable: $SSH_PUBLIC_KEY_FILE"
  CREATE_ARGS+=(--ssh-public-keys "$SSH_PUBLIC_KEY_FILE")
fi

printf 'Creating unprivileged CT %s from %s...\n' "$CTID" "$TEMPLATE_REF"
pct create "${CREATE_ARGS[@]}"
pct start "$CTID"

printf 'Waiting for CT %s...\n' "$CTID"
ready=0
for _ in $(seq 1 60); do
  if pct exec "$CTID" -- true >/dev/null 2>&1; then ready=1; break; fi
  sleep 1
done
(( ready == 1 )) || die "container did not become ready in time"

pct exec "$CTID" -- install -d -m 0700 /root/t3mp3st-bootstrap
for file in provision-inside-ct.sh t3mp3st.service t3mp3st.env t3mp3st-src-afc9dad1.tar.gz; do
  pct push "$CTID" "$PAYLOAD/$file" "/root/t3mp3st-bootstrap/$file" --perms 0600
done

pct exec "$CTID" -- env \
  ADMIN_USER="$ADMIN_USER" \
  NODE_VERSION="$NODE_VERSION" \
  NODE_LINUX_X64_SHA256="$NODE_LINUX_X64_SHA256" \
  CODEX_VERSION="$CODEX_VERSION" \
  bash /root/t3mp3st-bootstrap/provision-inside-ct.sh

pct exec "$CTID" -- systemctl is-active --quiet t3mp3st
pct exec "$CTID" -- curl -fsS http://127.0.0.1:3333/health >/dev/null

IP_ADDR="$(pct exec "$CTID" -- hostname -I 2>/dev/null | awk '{print $1}')"
printf '\nT3MP3ST CT %s is ready.\n' "$CTID"
printf 'Container IP: %s\n' "${IP_ADDR:-unknown}"
printf 'UI is loopback-only. From your workstation use:\n'
printf '  ssh -L 3333:127.0.0.1:3333 %s@%s\n' "$ADMIN_USER" "${IP_ADDR:-CT_IP}"
printf 'Then open http://127.0.0.1:3333/ui\n'
printf 'Codex login (optional): pct exec %s -- su - t3mp3st -c "codex login --device-auth"\n' "$CTID"

