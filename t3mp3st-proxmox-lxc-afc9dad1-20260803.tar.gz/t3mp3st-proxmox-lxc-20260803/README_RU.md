# T3MP3ST для Proxmox VE — готовый LXC-пакет

Пакет создаёт отдельный **непривилегированный Debian LXC** и устанавливает в него
T3MP3ST из зафиксированного исходного состояния `afc9dad1b27e438e36fdb0fd80c4dec26f3a02aa`.
Он не меняет Proxmox-хост, кроме создания нового CT, загрузки стандартного Debian-шаблона
и включения флага `firewall=1` на сетевой карте нового контейнера.

## Что получится

- Node.js `24.16.0`, проверяемый по SHA-256 с официального `nodejs.org`;
- T3MP3ST `1.0.0`, собранный внутри Linux-контейнера через `npm ci`;
- Codex CLI `0.146.0` (авторизация в пакет не включена);
- systemd-сервис `t3mp3st`, автозапуск и постоянные данные в `/var/lib/t3mp3st`;
- UI/API только на `127.0.0.1:3333` — наружу порт 3333 не публикуется;
- SSH без паролей и без входа root; рабочая учётная запись — `t3admin`;
- базовые диагностические утилиты: `nmap`, `dig`, `whois`, `jq`.

## Рекомендуемая схема

Размещайте CT в отдельном VLAN для security tooling. Разрешите исходящий трафик только
по правилам вашей организации. Не включайте nesting/privileged mode. Доступ к UI давайте
только через SSH-туннель. Встроенный HTTP API T3MP3ST не имеет собственной аутентификации.

## Развёртывание

1. Расшифруйте архив на административной машине (пароль передаётся отдельно):

```bash
openssl enc -d -aes-256-cbc -pbkdf2 -iter 600000 \
  -in t3mp3st-proxmox-lxc-afc9dad1-20260803.tar.gz.enc \
  -out t3mp3st-proxmox-lxc-afc9dad1-20260803.tar.gz
tar -xzf t3mp3st-proxmox-lxc-afc9dad1-20260803.tar.gz
```

2. Передайте распакованный каталог на Proxmox VE по SCP/SFTP.
3. На Proxmox-хосте:

```bash
cd t3mp3st-proxmox-lxc-20260803
cp config.env.example config.env
nano config.env
chmod +x deploy.sh verify.sh payload/provision-inside-ct.sh
sudo ./deploy.sh ./config.env
```

Обязательно укажите свободный `CTID`, существующие хранилища `PVE_STORAGE` и
`TEMPLATE_STORAGE`, правильный bridge/VLAN и файл публичного SSH-ключа. Если ключ не указан,
контейнер останется доступен через `pct enter CTID`, но удалённый SSH-вход будет закрыт.

Скрипт принципиально откажется продолжать, если выбранный CTID уже существует. Существующие
контейнеры он не изменяет и не удаляет.

## Доступ к War Room

```bash
ssh -L 3333:127.0.0.1:3333 t3admin@CT_IP
```

После этого откройте локально `http://127.0.0.1:3333/ui`.

## Авторизация Codex

Учётные данные и токены не упакованы. После развёртывания выполните на Proxmox-хосте:

```bash
pct exec CTID -- su - t3mp3st -c 'codex login --device-auth'
```

Затем перезапустите сервис:

```bash
pct exec CTID -- systemctl restart t3mp3st
```

## Проверка и журналы

```bash
sudo ./verify.sh CTID
pct exec CTID -- journalctl -u t3mp3st -f
```

## Резервное копирование

Добавьте CT в Proxmox Backup Server или в штатное расписание `vzdump`. Рабочее состояние
находится в `/var/lib/t3mp3st`; перед восстановлением на другой CT не публикуйте порт 3333
на сетевом интерфейсе.

## Важные ограничения

- Это воспроизводимый deployment bundle, а не чужой готовый rootfs: первый запуск скачивает
  Debian template, Node.js и npm-зависимости через HTTPS прямо на вашем Proxmox-хосте.
- Полный Kali-набор не ставится: он требует более широких привилегий/изоляции. Для тяжёлого
  offensive tooling безопаснее отдельная KVM VM.
- Используйте T3MP3ST только для ресурсов, на тестирование которых есть явное разрешение.
